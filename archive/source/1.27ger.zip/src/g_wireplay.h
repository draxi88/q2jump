#ifndef G_WIREPLAY_H
#define G_WIREPLAY_H

#include "g_local.h"

void print_wireplay_time(edict_t* ent, const char* map);

#endif